@echo off

setlocal EnableDelayedExpansion

set APP_DIR=%~dp0
set APP_NAME=GarminDiveFITTool.jar
set APP_PATH="%APP_DIR%%APP_NAME%"
call java -jar %APP_PATH% -f %*
pause